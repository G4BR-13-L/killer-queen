package queen.killerqueen.gestordecolaboradores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestordecolaboradoresApplicationTests {

	@Test
	void contextLoads() {
	}

}
