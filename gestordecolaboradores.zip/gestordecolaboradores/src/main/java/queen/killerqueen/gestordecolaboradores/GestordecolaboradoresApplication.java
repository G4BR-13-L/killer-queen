package queen.killerqueen.gestordecolaboradores;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestordecolaboradoresApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestordecolaboradoresApplication.class, args);
	}

}
